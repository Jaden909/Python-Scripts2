import PyEngine,pygame,sys,os,importlib
installedApps=[]
screen=pygame.display.set_mode((640,360))
computerScreen=pygame.image.load('computerScreen2.png')
def power():
    print('power')
powerButton=PyEngine.GameButton(x=0,y=300,function=power,imageResX=40,imageResY=60,hover=True)
#import clock
#installedApps.append(clock)
if __name__=='__main__':
    path=sys.path[0]
    for root, dirs, files in os.walk(f'{path}\\Apps'):
        for name in dirs:
            if name[0].isupper():
                #print(name)
                sys.path.insert(0,f'{path}\\Apps\\{name}')
                installedApps.append(importlib.import_module(name.lower()))
    while True:
        if pygame.event.get(pygame.QUIT):
            exit()
        screen.blit(computerScreen,(0,0))
        for app in installedApps:
            app.loop()
        powerButton.listen()
        #print(pygame.mouse.get_pos())
        pygame.display.update()