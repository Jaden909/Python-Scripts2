import PyEngine,pygame,sys,os,importlib,time
pygame.init() 
screen=pygame.display.set_mode((1280,720),pygame.SCALED)
pygame.display.set_caption('PyComputer')
icon=pygame.image.load('icon3.png')
pygame.display.set_icon(icon)
path=sys.path[0]
mods=True
booting=True
cursorImg=pygame.image.load('Assets\\Cursors\\arrow.png')
linkcursorImg=pygame.image.load('Assets\\Cursors\\link2.png')
loadingScreen=pygame.image.load('Assets\\Screens\\loadingScreen.png').convert()
begin=0

if __name__=='__main__':
    print(sys.path[0])
    computerScreen=pygame.image.load('Assets\\Screens\\computerScreen5.png').convert()
    def power():
        exit()
    def modConfig():
        if mods:
            for app in installedApps:
                if app.id=='modlist':
                    app.init()
                    pygame.mouse.set_cursor(cursor)
                    break
        else:
            print('Mods Disabled. How are you going to manage nothing?')
    powerButton=PyEngine.GameButton(x=0,y=600,function=power,imageResX=114,imageResY=120,hover=True,image=None,hoverSprite=linkcursorImg,notHoverSprite=cursorImg)
    modConfigButton=PyEngine.GameButton(x=0,y=0,function=modConfig,imageResX=114,imageResY=120,hover=True,image=None,hoverSprite=linkcursorImg,notHoverSprite=cursorImg)
    cursor=pygame.cursors.Cursor((0,0),cursorImg)
    linkcursor=pygame.cursors.Cursor((0,0),linkcursorImg)
    try:
        import PyBIOS
        mods=PyBIOS.mods
    except ImportError:
        print('PyBIOS missing or damaged. Booting in safe mode...')
        mods=False
        booting=True
    if mods:    
        try:
            sys.path.insert(1,f'{path}\\Apps\\ModManager')
            modmanager=importlib.import_module('modmanager')
        except:
            print('Mod manager missing. Mod support disabled.')
            mods=False
    if mods:
        begin=time.time()
        installedApps=modmanager.loadMods(f'{path}\\Apps',loadingScreen,screen)
        timeTaken=time.time()-begin
        print(f'Mods loaded in {timeTaken} seconds.') 
    pygame.mouse.set_cursor(cursor) 
    while True:
        if pygame.event.get(pygame.QUIT):
            exit()
        screen.blit(computerScreen,(0,0))
        if mods:
            for app in installedApps:
                app.loop()
                if app.id=='modlist':
                    if not app.script.windowOpen:
                        modConfigButton.listen()
        powerButton.listen()
        pygame.display.update()      