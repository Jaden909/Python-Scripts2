import Computer,pygame
circle=pygame.image.load('Apps\\Circle\\media\\circle.png')
def loop():
    #Computer.screen.blit(circle,(250,100))
    pass
