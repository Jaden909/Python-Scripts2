import Computer,pygame,PyEngine,os,importlib

i=1
#class App:
#    def __init__(self,name,title,description,version,id,author,modified,script,icon):
#        self.name=name
#        self.title=title
#        self.description=description
#        self.version=version
#        self.id=id
#        self.author=author
#        self.modified=modified
#        self.script=script
#        self.icon=icon
#    def loop(self):
#        self.script.loop()
#    def init(self):
#        self.script.init()
#    def config(self):
#        self.script.config()    
for root, dirs, files in os.walk(f'{Computer.path}\\Apps'):
    for name in dirs:
        if name[0].isupper():
            installedMods=Computer.installedApps
            try:
                meta=PyEngine.load(f'{Computer.path}\\Apps\\{name}\\meta.json')
                
            except:
                print(f'ERROR LOADING {name}:')
                print(f'The mod "{name}" doesn\'t seem to have a meta.json file. Unable to retrieve meta data. The Mod might still work.')
                continue
            print(f'App {i}:')
            print(meta.get('title'))
            print(meta.get('description'))
            print(meta.get('version'))
            print(meta.get('id'))
            print(meta.get('author'))
            print(meta.get('modified'))
            #app=App(name,meta.get('title'),meta.get('description'),meta.get('version'),meta.get('id'),meta.get('author'),meta.get('modified'),importlib.import_module(name.lower()),None)
            i+=1
print(f'{i-1} apps installed.')      
def loop():
    pass 
