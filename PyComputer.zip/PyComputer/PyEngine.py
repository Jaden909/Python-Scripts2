"""Game Engine for Python. Requires Pygame."""
import pygame,json,os,sys,importlib
_mouseDown=False
def animation(moveList:list,fps:int,frames:int,screen,x,y):
    """Pygame animation."""
    for i in range(frames):    
        if i>len(moveList):
            i=0
        clock=pygame.time.Clock()
        clock.tick(fps)
        currentSprite=moveList[i]
        screen.blit(currentSprite,(x,y))
        pygame.display.update()
def wasdInput(WFunction=None,AFunction=None,SFunction=None,DFunction=None):
    """Simple WASD/arrow keys input listener. Also supports arrow keys. Args are functions to run when respective key is pressed"""
    keys=pygame.key.get_pressed()
    if keys[pygame.K_LEFT]or keys[pygame.K_a]and AFunction!=None:
        AFunction()
    if keys[pygame.K_RIGHT]or keys[pygame.K_d]and DFunction!=None:
        DFunction()
    if keys[pygame.K_DOWN]or keys[pygame.K_s]and SFunction!=None:
        SFunction()
    if keys[pygame.K_UP]or keys[pygame.K_w]and WFunction!=None:
        WFunction()
class GameButton:
    """Create a button that can trigger a function if clicked on
    Required Args: x, y, imageRes(if image is used), use imageResX and imageResY for non-square buttons
    Optional Args: image,function,hoverSprite,notHoverSprite (if using custom cursor),hover
    """
    def __init__(self,**kwargs):
        self.hovering=False
        #REQUIRED ARGS
        if 'x' in kwargs and 'y' in kwargs:  
            self.x=kwargs.get('x')
            self.y=kwargs.get('y')
        #Error raised if required args are not found
        else:
            raise ValueError('GameButton requires arguments x and y')
        #Optional arg check: if image not found default is used
        if 'image' in kwargs and kwargs.get('image')is None:    
                self.image=None
                self.square=False
                self.imageResX=kwargs.get('imageResX')
                self.imageResY=kwargs.get('imageResY')
        elif 'image' in kwargs:
            self.image=pygame.image.load(kwargs.get('image')).convert()
            if'imageRes' in kwargs:
                self.imageRes=kwargs.get('imageRes')
                self.square=True
            elif 'imageResX'in kwargs and 'imageResY' in kwargs:
                self.imageResX=kwargs.get('imageResX')
                self.imageResY=kwargs.get('imageResY')
                self.square=False
            else:
                raise ValueError('image requires either imageRes for square buttons or imageResX and imageResY for non-square buttons')
        else:
            self.image=pygame.image.load('Defaults\\DEFAULTBUTTON.png').convert()
            self.imageRes=64
            self.square=True
        #Optional arg: default assinged if not found
        if'function' in kwargs:
            self.function=kwargs.get('function')
        else:
            self.function=lambda:print('This button doesn\'t have a function assigned to it. It currently does nothing.')
        #Optional arg: Default value is false
        if 'hover' in kwargs:
            self.hover=kwargs.get('hover')
        else:
            self.hover=False
        if 'hoverSprite' in kwargs:
            self.hoverSprite=kwargs.get('hoverSprite')
            self.hoverCursor=pygame.cursors.Cursor((2,24),self.hoverSprite)
        else:
            self.hoverCursor=pygame.SYSTEM_CURSOR_HAND
        if 'notHoverSprite' in kwargs:
            self.notHoverSprite=kwargs.get('notHoverSprite') 
            self.notHoverCursor=pygame.cursors.Cursor((2,24),self.notHoverSprite)   
        else:
            self.notHoverCursor=pygame.SYSTEM_CURSOR_ARROW     
    #Blits button to screen provided
    def show(self,**kwargs):
        'Blit button to screen. Screen to blit to required. Requires defined image'
        screen=kwargs.get('screen')
        screen.blit(self.image,(self.x,self.y))
    
    #Listens for mouse clicks: should be in a loop to work properly
    def listen(self):    
        "Listens for clicks on the button. Should be in a loop."
        global _mouseDown
        left,middle,right=pygame.mouse.get_pressed()
        #Hover
        if self.hover:    
            if self.square:
                mouseX,mouseY=pygame.mouse.get_pos()
                if mouseX>self.x and mouseX<self.x+self.imageRes and mouseY>self.y and mouseY<self.y+self.imageRes:
                    pygame.mouse.set_cursor(self.hoverCursor)
                    self.hovering=True
                elif self.hovering:
                    pygame.mouse.set_cursor(self.notHoverCursor)
                    self.hovering=False
            else:
                mouseX,mouseY=pygame.mouse.get_pos()
                if mouseX>self.x and mouseX<self.x+self.imageResX and mouseY>self.y and mouseY<self.y+self.imageResY:
                    pygame.mouse.set_cursor(self.hoverCursor)
                else:
                    pygame.mouse.set_cursor(self.notHoverCursor)
        #CLick Event
        if left:
            if self.square:    
                mouseX,mouseY=pygame.mouse.get_pos()
                if mouseX>self.x and mouseX<self.x+self.imageRes and mouseY>self.y and mouseY<self.y+self.imageRes and _mouseDown==False:
                    self.function()
                    _mouseDown=True
            else:
                mouseX,mouseY=pygame.mouse.get_pos()
                if mouseX>self.x and mouseX<self.x+self.imageResX and mouseY>self.y and mouseY<self.y+self.imageResY and _mouseDown==False:
                    self.function()
                    _mouseDown=True
        else: _mouseDown=False
class Vector2:
    def __init__(self,x:int|float,y:int|float):
        self.value=(x,y)
    def translate(self,x=0,y=0):
        self.x=self.value.__getitem__(0)
        self.y=self.value.__getitem__(1)
        self.x+=x
        self.y+=y
        self.value=(self.x,self.y)
class staticImage:
    "Static Graphic that doesn't move. Requires x,y and image"
    def __init__(self,**kwargs):
        if 'x' in kwargs and 'y' in kwargs and 'image' in kwargs:
            self.x=kwargs.get('x')
            self.y=kwargs.get('y')            
            self.image=pygame.image.load(kwargs.get('image')).convert()
        else:
            raise ValueError('staticImage requires args:x,y and image')
    def show(self,screen):
        screen.blit(self.image,(self.x,self.y))
#Save/Load system
def save(saveFile:str,save):
    "Save a dictionary of variables to a json file"
    _save=save
    with open(saveFile,'w') as f:
        json.dump(_save,f)
def load(saveFile:str)-> dict:
    "Load a dictionary of variables from a json file and return it"
    _save=json.load(open(saveFile))
    return _save
def checkHover(x1:int,x2:int,y1:int,y2:int,function):
    "Runs a function if mouse is in given area"
    mouseX,mouseY=pygame.mouse.get_pos()
    if mouseX>x1 and mouseX<x2 and mouseY>y1 and mouseY<y2:
        function()
def loadMods(modDir:str,loadingScreen:pygame.Surface=None,screen:pygame.Surface=None):
    "Load mods in given directory. Returns list of loaded mods as Module objects. The folder containing each mod's files must start with an uppercase letter and the .py file must be the same name but lowercase."
    loadedMods=[]
    class Mod:
        def __init__(self,name,title,description,version,id,author,modified,script,icon):
            self.name=name
            self.title=title
            self.description=description
            self.version=version
            self.id=id
            self.author=author
            self.modified=modified
            self.script=script
            self.icon=icon
        def loop(self):
            self.script.loop()
        def init(self):
            self.script.init()
        def config(self):
            self.script.config() 
    for root, dirs, files in os.walk(f'{modDir}'):
            for name in dirs:
                if name[0].isupper():
                    sys.path.insert(1,f'{modDir}\\{name}')
                    meta=load(f'{modDir}\\{name}\\meta.json')
                    mod=Mod(name,meta.get('title'),meta.get('description'),meta.get('version'),meta.get('id'),meta.get('author'),meta.get('modified'),importlib.import_module(name.lower()),None)
                    loadedMods.append(mod)
                    if not loadingScreen is None:
                        screen.blit(loadingScreen,(0,0))    
    return loadedMods
if __name__=='__main__':
    print('This script doesn\'t work on its own. Import it into a project to use the functions and classes defined here')
else:
    print('Using PyEngine v0.2 DEV') 